﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Data.OleDb;
using System.Drawing;
using school_management;
namespace school_management;

public partial class classroom : Form
{
    private string? currentPhotoPath;
    public classroom()
    {
        InitializeComponent();
        LoadData();
        ClearFields();
        DataGridViewClassrooms.CellClick += DataGridViewClassrooms_CellContentClick;
    }

    //===========================> All Methods <=================================
    private void ClearFields()
    {
        txtClassroomID.Text = GetNextClassroomId().ToString();
        txtClassroomName.Clear();
        txtCapacity.Clear();
        pictureBoxPhoto.Image = null;
    }
    private int GetNextClassroomId()
    {
        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            string query = "SELECT ISNULL(MAX(classroom_id), 0) + 1 FROM Classrooms";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                return (int)command.ExecuteScalar();
            }
        }
    }


    private bool ClassroomIdExists(int classroomId)
    {
        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            string query = "SELECT COUNT(*) FROM Classrooms WHERE classroom_id = @classroomId";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@classroomId", classroomId);
                connection.Open();
                return (int)command.ExecuteScalar() > 0;
            }
        }
    }

    private void AddClassroom()
    {
        int classroomId;
        if (!int.TryParse(txtClassroomID.Text, out classroomId))
        {
            MessageBox.Show("Please enter a valid Classroom ID.");
            return;
        }
        if (ClassroomIdExists(classroomId))
        {
            MessageBox.Show("Classroom ID already exists. Please use a different ID.");
            return;
        }
        byte[] photoData = GetImageBytes(currentPhotoPath);

        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            string query = "INSERT INTO Classrooms (classroom_id, classroom_name, capacity, photo) VALUES (@id, @name, @capacity, @photo)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@id", classroomId);
                command.Parameters.AddWithValue("@name", txtClassroomName.Text);
                command.Parameters.AddWithValue("@capacity", int.Parse(txtCapacity.Text));
                command.Parameters.AddWithValue("@photo", (object)photoData ?? DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        MessageBox.Show("Classroom added successfully!");
    }
    private void LoadClassrooms()
    {
        try
        {
            using (SqlConnection connection = DatabaseHelpers.GetConnection())
            {
                string query = "SELECT classroom_id, classroom_name, capacity, photo FROM Classrooms";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                DataGridViewClassrooms.DataSource = dataTable;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error loading classrooms: {ex.Message}");
        }
    }
    private void RefreshDataGridView()
    {
        try
        {
            using (SqlConnection connection = DatabaseHelpers.GetConnection())
            {
                string query = "SELECT classroom_id, classroom_name, capacity, photo FROM Classrooms";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    DataGridViewClassrooms.DataSource = table;
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error refreshing DataGridView: " + ex.Message);
        }
    }
    private byte[] GetImageBytes(string imagePath)
    {
        if (string.IsNullOrEmpty(imagePath))
        {
            throw new ArgumentException("Image path cannot be null or empty.");
        }

        return File.ReadAllBytes(imagePath);
    }

    //==============================> Form Student's Score List's Components<===============================
    private void Form1_Load(object sender, EventArgs e)
    {
        LoadSubject();

    }
    private void LoadSubject()
    {
        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            connection.Open();
            SqlCommand command = new SqlCommand("SELECT subject_name FROM Subjects", connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                listBoxSubjects.Items.Add(reader["subject_name"].ToString());
            }
        }
    }

    private void listBoxSubjects_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (listBoxSubjects.SelectedItem != null)
        {
            string selectedSubject = listBoxSubjects.SelectedItem.ToString();
            LoadStudentScores(selectedSubject);
        }
    }
    private void LoadStudentScores(string subject)
    {
        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
                    "SELECT s.first_name, s.last_name, MAX(sc.score) AS max_score " +
                    "FROM Scores sc " +
                    "JOIN Students s ON sc.student_id = s.id " +
                    "JOIN Subjects sb ON sc.subject_id = sb.subject_id " +
                    "WHERE sb.subject_name = @subjectName " +
                    "GROUP BY s.first_name, s.last_name", connection);

                command.Parameters.AddWithValue("@subjectName", subject);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataGridViewScores.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }


    private void buttonBack_Click(object sender, EventArgs e)
    {
        Dashboard dashboard = new Dashboard();
        dashboard.Show();
        this.Hide(); // Hide the login form
    }

    private void buttonLogOut_Click(object sender, EventArgs e)
    {
        Login login = new Login();
        login.Show();
        this.Hide(); // Hide the login form

    }



    //=====================> For Form Classroom's Components <=====================================
    private void LoadData()
    {
        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            string query = "SELECT classroom_id, classroom_name, capacity, photo FROM Classrooms";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                DataGridViewClassrooms.DataSource = dataTable; // Bind the DataTable to the DataGridView
                DataGridViewClassrooms.DefaultCellStyle.BackColor = Color.White;
                DataGridViewClassrooms.DefaultCellStyle.ForeColor = Color.Black;
                DataGridViewClassrooms.DefaultCellStyle.SelectionBackColor = Color.Blue;
                DataGridViewClassrooms.DefaultCellStyle.SelectionForeColor = Color.White;
            }
        }
    }
    private void button2_Click(object sender, EventArgs e)
    {
        if (pictureBoxPhoto.Image == null)
        {
            MessageBox.Show("Please select a photo.");
            return;
        }

        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            string query = "INSERT INTO Classrooms (classroom_name, capacity, photo) VALUES (@name, @capacity, @photo)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@name", txtClassroomName.Text);
                command.Parameters.AddWithValue("@capacity", int.Parse(txtCapacity.Text));
                command.Parameters.AddWithValue("@photo", GetImageBytes(currentPhotoPath));

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Classroom added successfully.");
                    LoadData(); // Refresh the data grid
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }

    private void buttonUpdate_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtClassroomID.Text) ||
   string.IsNullOrWhiteSpace(txtClassroomName.Text) ||
   string.IsNullOrWhiteSpace(txtCapacity.Text))
        {
            MessageBox.Show("Please fill in all fields.");
            return;
        }

        if (!int.TryParse(txtClassroomID.Text, out int classroomId))
        {
            MessageBox.Show("Invalid Classroom ID.");
            return;
        }

        byte[] photoData = null;
        try
        {
            if (!string.IsNullOrEmpty(currentPhotoPath))
            {
                photoData = GetImageBytes(currentPhotoPath);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error loading image: " + ex.Message);
            return;
        }

        try
        {
            using (SqlConnection connection = DatabaseHelpers.GetConnection())
            {
                string query = "UPDATE Classrooms SET classroom_name = @name, capacity = @capacity" +
                               (photoData != null ? ", photo = @photo " : " ") +
                               "WHERE classroom_id = @id";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.Add("@id", SqlDbType.Int).Value = classroomId;
                    command.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtClassroomName.Text.Trim();
                    command.Parameters.Add("@capacity", SqlDbType.Int).Value = int.Parse(txtCapacity.Text.Trim());

                    // Only add the photo parameter if photoData is not null
                    if (photoData != null)
                    {
                        command.Parameters.Add("@photo", SqlDbType.VarBinary).Value = photoData;
                    }

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("No record was updated. Please check the classroom ID.");
                    }
                    else
                    {
                        MessageBox.Show("Update successful!");
                        RefreshDataGridView(); // Refresh DataGridView to show updated values
                    }
                }
            }
        }
        catch (SqlException sqlEx)
        {
            MessageBox.Show("SQL Error: " + sqlEx.Message);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
        }
    }
    private void buttonDelete_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtClassroomID.Text))
        {
            MessageBox.Show("Please enter a Classroom ID.");
            return;
        }

        using (SqlConnection connection = DatabaseHelpers.GetConnection())
        {
            string query = "DELETE FROM Classrooms WHERE classroom_id = @id";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@id", int.Parse(txtClassroomID.Text));

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Classroom deleted successfully.");
                    LoadData();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }



    private void buttonClear_Click(object sender, EventArgs e)
    {
        ClearFields();
    }

    private void buttonBrowse_Click(object sender, EventArgs e)
    {
        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                currentPhotoPath = openFileDialog.FileName;
                pictureBoxPhoto.ImageLocation = currentPhotoPath; // Display the selected image
            }
        }

    }

    private void DataGridViewClassrooms_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex >= 0)
        {
            DataGridViewRow row = DataGridViewClassrooms.Rows[e.RowIndex];
            ClearFields();
            txtClassroomID.Text = row.Cells["classroom_id"].Value?.ToString() ?? string.Empty;
            txtClassroomName.Text = row.Cells["classroom_name"].Value?.ToString() ?? string.Empty;
            txtCapacity.Text = row.Cells["capacity"].Value?.ToString() ?? string.Empty;
            if (row.Cells["photo"].Value != DBNull.Value && row.Cells["photo"].Value is byte[] photoData)
            {
                using (var ms = new MemoryStream(photoData))
                {
                    pictureBoxPhoto.Image = Image.FromStream(ms);
                }
            }
            else
            {
                pictureBoxPhoto.Image = null;
            }
        }

    }

    private void txtClassroomID_TextChanged(object sender, EventArgs e)
    {
    }

    private void dataGridViewScores_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }
}
