﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace school_management
{
    public static class DatabaseHelpers
    {
        private static string connectionString =
            @"Data Source=MSI-ROZA\SQLEXPRESS1;Initial Catalog=school2_db;Integrated Security=True;TrustServerCertificate=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
