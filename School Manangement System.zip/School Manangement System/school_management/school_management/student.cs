﻿using System.Data;
using System;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace school_management
{
    public partial class student : Form
    {
        private string connectionString = @"Data Source=MSI-ROZA\SQLEXPRESS1;Initial Catalog=school2_db;Integrated Security=True;TrustServerCertificate=True";

        public student()
        {
            InitializeComponent();
            LoadStudents();
            dataGridViewStudents.CellClick += dataGridView1_CellContentClick_1;


        }


        //------------------------All Methods-------------------------
        private void LoadStudents()
        {
            using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                string query = "SELECT student_id,first_name, last_name, date_of_birth, address, phone_number, photo FROM Students";
                System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridViewStudents.DataSource = dt;
            }
        }
        private void ClearFields()
        {
            txtStudentID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            //dtpDateOfBirth.Clear();
            txtAddress.Clear();
            txtPhone.Clear();
            pictureBox.Image = null;
        }

        //-----------------------------------------------

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide(); // Hide the login form
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadStudents();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStudentID.Text))
            {
                MessageBox.Show("Student ID is required for updating.");
                return;
            }

            using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                string query = "UPDATE Students SET first_name = @FirstName, last_name = @LastName, " +
                               "date_of_birth = @DateOfBirth, address = @Address, phone_number = @PhoneNumber, photo = @Photo " +
                               "WHERE student_id = @StudentID";

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", dtpDateOfBirth.Value);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);

                    // Handle photo field
                    if (pictureBox.Image != null)
                    {
                        using (var ms = new MemoryStream())
                        {
                            pictureBox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            cmd.Parameters.Add("@Photo", SqlDbType.VarBinary).Value = ms.ToArray();
                        }
                    }
                    else
                    {
                        cmd.Parameters.Add("@Photo", SqlDbType.VarBinary).Value = DBNull.Value;
                    }

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student updated successfully!");
                        LoadStudents(); // Refresh the data grid
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating data: " + ex.Message);
                    }
                }
            }

        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("First Name and Last Name are required.");
                return;
            }

            using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                string query = "INSERT INTO Students (student_id,first_name, last_name, date_of_birth, address, phone_number, photo) " +
                               "VALUES (@StudentID,@FirstName, @LastName, @DateOfBirth, @Address, @PhoneNumber, @Photo)";

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", dtpDateOfBirth.Value);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);

                    // Handle photo field
                    if (pictureBox.Image != null)
                    {
                        using (var ms = new MemoryStream())
                        {
                            pictureBox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            cmd.Parameters.Add("@Photo", SqlDbType.VarBinary).Value = ms.ToArray();
                        }
                    }
                    else
                    {
                        cmd.Parameters.Add("@Photo", SqlDbType.VarBinary).Value = DBNull.Value;
                    }

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student inserted successfully!");
                        LoadStudents(); // Refresh the data grid
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error inserting data: " + ex.Message);
                    }
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtStudentID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtAddress.Clear();
            txtPhone.Clear();
            dtpDateOfBirth.Value = DateTime.Today;
            pictureBox.Image = null; // Clear the photo;lk
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStudentID.Text))
            {
                MessageBox.Show("Student ID is required for deletion.");
                return;
            }

            using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                string query = "DELETE FROM Students WHERE student_id = @StudentID";

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student deleted successfully!");
                        LoadStudents(); // Refresh the data grid
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting data: " + ex.Message);
                    }
                }
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide(); // Hide the login form
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewStudents.Rows[e.RowIndex];
                ClearFields();
                txtStudentID.Text = row.Cells["student_id"].Value?.ToString() ?? string.Empty;
                txtFirstName.Text = row.Cells["first_name"].Value?.ToString() ?? string.Empty;
                txtLastName.Text = row.Cells["last_name"].Value?.ToString() ?? string.Empty;
                dtpDateOfBirth.Text = row.Cells["date_of_birth"].Value?.ToString() ?? string.Empty;
                txtAddress.Text = row.Cells["address"].Value?.ToString() ?? string.Empty;
                txtPhone.Text = row.Cells["phone_number"].Value?.ToString() ?? string.Empty;
                if (row.Cells["photo"].Value != DBNull.Value && row.Cells["photo"].Value is byte[] photoData)
                {
                    using (var ms = new MemoryStream(photoData))
                    {
                        pictureBox.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    pictureBox.Image = null;
                }
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "C:\\pic";
                openFileDialog.Filter = "Image files (*.jpg; *.jpeg; *.png)|*.jpg;*.jpeg;*.png|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 1;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    pictureBox.Image = Image.FromFile(filePath);
                }
            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
