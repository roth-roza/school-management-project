﻿namespace school_management
{
    partial class classroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(classroom));
            listBoxSubjects = new ComboBox();
            textBox3 = new TextBox();
            dataGridViewScores = new DataGridView();
            buttonBack = new Button();
            buttonLogOut = new Button();
            textBox1 = new TextBox();
            label1 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            DataGridViewClassrooms = new DataGridView();
            buttonBrowse = new Button();
            buttonUpdate = new Button();
            buttonClear = new Button();
            buttonAdd = new Button();
            buttonDelete = new Button();
            pictureBoxPhoto = new PictureBox();
            txtCapacity = new TextBox();
            txtClassroomName = new TextBox();
            txtClassroomID = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewScores).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewClassrooms).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPhoto).BeginInit();
            SuspendLayout();
            // 
            // listBoxSubjects
            // 
            listBoxSubjects.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBoxSubjects.FormattingEnabled = true;
            listBoxSubjects.Location = new Point(185, 55);
            listBoxSubjects.Name = "listBoxSubjects";
            listBoxSubjects.Size = new Size(246, 27);
            listBoxSubjects.TabIndex = 2;
            listBoxSubjects.SelectedIndexChanged += listBoxSubjects_SelectedIndexChanged;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(255, 192, 255);
            textBox3.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(76, 129);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(313, 27);
            textBox3.TabIndex = 3;
            textBox3.Text = "Student's Score ";
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // dataGridViewScores
            // 
            dataGridViewScores.BackgroundColor = SystemColors.ActiveCaption;
            dataGridViewScores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewScores.Location = new Point(23, 186);
            dataGridViewScores.Name = "dataGridViewScores";
            dataGridViewScores.RowHeadersWidth = 51;
            dataGridViewScores.Size = new Size(408, 220);
            dataGridViewScores.TabIndex = 4;
            dataGridViewScores.CellContentClick += dataGridViewScores_CellContentClick;
            // 
            // buttonBack
            // 
            buttonBack.BackColor = Color.Lime;
            buttonBack.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBack.Location = new Point(152, 445);
            buttonBack.Name = "buttonBack";
            buttonBack.Size = new Size(106, 40);
            buttonBack.TabIndex = 5;
            buttonBack.Text = "Back";
            buttonBack.UseVisualStyleBackColor = false;
            buttonBack.Click += buttonBack_Click;
            // 
            // buttonLogOut
            // 
            buttonLogOut.BackColor = Color.Red;
            buttonLogOut.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonLogOut.Location = new Point(30, 442);
            buttonLogOut.Name = "buttonLogOut";
            buttonLogOut.Size = new Size(106, 40);
            buttonLogOut.TabIndex = 6;
            buttonLogOut.Text = "Log Out";
            buttonLogOut.UseVisualStyleBackColor = false;
            buttonLogOut.Click += buttonLogOut_Click;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.BackColor = SystemColors.Highlight;
            textBox1.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox1.ForeColor = Color.White;
            textBox1.Location = new Point(0, 0);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(447, 27);
            textBox1.TabIndex = 7;
            textBox1.Text = "Student's Score List By Subject";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Cyan;
            label1.Font = new Font("Arial Narrow", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(16, 60);
            label1.Name = "label1";
            label1.Size = new Size(111, 22);
            label1.TabIndex = 8;
            label1.Text = "Choose Subject";
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(dataGridViewScores);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(listBoxSubjects);
            panel1.Location = new Point(7, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(447, 431);
            panel1.TabIndex = 9;
            // 
            // panel2
            // 
            panel2.Controls.Add(DataGridViewClassrooms);
            panel2.Controls.Add(buttonBrowse);
            panel2.Controls.Add(buttonUpdate);
            panel2.Controls.Add(buttonClear);
            panel2.Controls.Add(buttonAdd);
            panel2.Controls.Add(buttonDelete);
            panel2.Controls.Add(pictureBoxPhoto);
            panel2.Controls.Add(txtCapacity);
            panel2.Controls.Add(txtClassroomName);
            panel2.Controls.Add(txtClassroomID);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(textBox2);
            panel2.ForeColor = Color.White;
            panel2.Location = new Point(477, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(628, 493);
            panel2.TabIndex = 10;
            // 
            // DataGridViewClassrooms
            // 
            DataGridViewClassrooms.BackgroundColor = SystemColors.ActiveCaption;
            DataGridViewClassrooms.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewClassrooms.GridColor = Color.Black;
            DataGridViewClassrooms.Location = new Point(40, 228);
            DataGridViewClassrooms.Name = "DataGridViewClassrooms";
            DataGridViewClassrooms.RowHeadersWidth = 51;
            DataGridViewClassrooms.Size = new Size(553, 206);
            DataGridViewClassrooms.TabIndex = 15;
            DataGridViewClassrooms.CellContentClick += DataGridViewClassrooms_CellContentClick;
            // 
            // buttonBrowse
            // 
            buttonBrowse.BackColor = Color.FromArgb(224, 224, 224);
            buttonBrowse.ForeColor = Color.Black;
            buttonBrowse.Location = new Point(374, 184);
            buttonBrowse.Name = "buttonBrowse";
            buttonBrowse.Size = new Size(94, 38);
            buttonBrowse.TabIndex = 14;
            buttonBrowse.Text = "  Browse";
            buttonBrowse.UseVisualStyleBackColor = false;
            buttonBrowse.Click += buttonBrowse_Click;
            // 
            // buttonUpdate
            // 
            buttonUpdate.BackColor = Color.FromArgb(192, 255, 255);
            buttonUpdate.ForeColor = Color.Black;
            buttonUpdate.Location = new Point(156, 440);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(110, 40);
            buttonUpdate.TabIndex = 13;
            buttonUpdate.Text = "Update";
            buttonUpdate.UseVisualStyleBackColor = false;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = Color.FromArgb(192, 255, 255);
            buttonClear.ForeColor = Color.Black;
            buttonClear.Location = new Point(483, 440);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(110, 40);
            buttonClear.TabIndex = 12;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.BackColor = Color.FromArgb(192, 255, 255);
            buttonAdd.ForeColor = Color.Black;
            buttonAdd.Location = new Point(40, 440);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(110, 40);
            buttonAdd.TabIndex = 11;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += button2_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = Color.FromArgb(192, 255, 255);
            buttonDelete.ForeColor = Color.Black;
            buttonDelete.Location = new Point(361, 441);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(116, 40);
            buttonDelete.TabIndex = 10;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // pictureBoxPhoto
            // 
            pictureBoxPhoto.BackColor = Color.Gray;
            pictureBoxPhoto.Image = (Image)resources.GetObject("pictureBoxPhoto.Image");
            pictureBoxPhoto.Location = new Point(474, 31);
            pictureBoxPhoto.Name = "pictureBoxPhoto";
            pictureBoxPhoto.Size = new Size(141, 191);
            pictureBoxPhoto.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBoxPhoto.TabIndex = 9;
            pictureBoxPhoto.TabStop = false;
            // 
            // txtCapacity
            // 
            txtCapacity.Location = new Point(171, 170);
            txtCapacity.Name = "txtCapacity";
            txtCapacity.Size = new Size(161, 28);
            txtCapacity.TabIndex = 8;
            // 
            // txtClassroomName
            // 
            txtClassroomName.Location = new Point(171, 107);
            txtClassroomName.Name = "txtClassroomName";
            txtClassroomName.Size = new Size(199, 28);
            txtClassroomName.TabIndex = 7;
            // 
            // txtClassroomID
            // 
            txtClassroomID.Location = new Point(171, 52);
            txtClassroomID.Name = "txtClassroomID";
            txtClassroomID.Size = new Size(161, 28);
            txtClassroomID.TabIndex = 6;
            txtClassroomID.TextChanged += txtClassroomID_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Black;
            label6.Location = new Point(416, 31);
            label6.Name = "label6";
            label6.Size = new Size(52, 22);
            label6.TabIndex = 5;
            label6.Text = "Photo";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Black;
            label5.Location = new Point(13, 170);
            label5.Name = "label5";
            label5.Size = new Size(71, 22);
            label5.TabIndex = 4;
            label5.Text = "Capacity";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Black;
            label4.Location = new Point(235, 129);
            label4.Name = "label4";
            label4.Size = new Size(0, 22);
            label4.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Black;
            label3.Location = new Point(13, 113);
            label3.Name = "label3";
            label3.Size = new Size(132, 22);
            label3.TabIndex = 2;
            label3.Text = "Classroom Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Black;
            label2.Location = new Point(13, 55);
            label2.Name = "label2";
            label2.Size = new Size(106, 22);
            label2.TabIndex = 1;
            label2.Text = "Classroom ID";
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.MenuHighlight;
            textBox2.ForeColor = SystemColors.InactiveBorder;
            textBox2.Location = new Point(3, 0);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(670, 28);
            textBox2.TabIndex = 0;
            textBox2.Text = "Classroom";
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 22F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(224, 224, 224);
            ClientSize = new Size(1117, 510);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(buttonLogOut);
            Controls.Add(buttonBack);
            Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewScores).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewClassrooms).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPhoto).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private ComboBox listBoxSubjects;
        private TextBox textBox3;
        private DataGridView dataGridViewScores;
        private Button buttonBack;
        private Button buttonLogOut;
        private TextBox textBox1;
        private Label label1;
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox2;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtCapacity;
        private TextBox txtClassroomName;
        private TextBox txtClassroomID;
        private Label label6;
        private Button buttonUpdate;
        private Button buttonClear;
        private Button buttonAdd;
        private Button buttonDelete;
        private PictureBox pictureBoxPhoto;
        private Button buttonBrowse;
        private DataGridView DataGridViewClassrooms;
    }
}