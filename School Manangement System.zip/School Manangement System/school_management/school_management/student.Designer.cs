﻿namespace school_management
{
    partial class student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(student));
            txtstuID = new Label();
            txtFN = new Label();
            txtLN = new Label();
            txtDoB = new Label();
            txtAddr = new Label();
            txtPh = new Label();
            txtStudentID = new TextBox();
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            txtAddress = new TextBox();
            txtPhone = new TextBox();
            panel1 = new Panel();
            label7 = new Label();
            pictureBox = new PictureBox();
            btnInsert = new Button();
            btnUpdate = new Button();
            btnClear = new Button();
            btnDelete = new Button();
            btnback = new Button();
            btnlogout = new Button();
            dtpDateOfBirth = new DateTimePicker();
            dataGridViewStudents = new DataGridView();
            btnBrowse = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudents).BeginInit();
            SuspendLayout();
            // 
            // txtstuID
            // 
            txtstuID.AutoSize = true;
            txtstuID.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            txtstuID.Location = new Point(12, 117);
            txtstuID.Name = "txtstuID";
            txtstuID.Size = new Size(95, 25);
            txtstuID.TabIndex = 0;
            txtstuID.Text = "StudentID ";
            txtstuID.Click += label1_Click;
            // 
            // txtFN
            // 
            txtFN.AutoSize = true;
            txtFN.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            txtFN.Location = new Point(12, 181);
            txtFN.Name = "txtFN";
            txtFN.Size = new Size(102, 25);
            txtFN.TabIndex = 1;
            txtFN.Text = "First Name";
            // 
            // txtLN
            // 
            txtLN.AutoSize = true;
            txtLN.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            txtLN.Location = new Point(8, 248);
            txtLN.Name = "txtLN";
            txtLN.Size = new Size(99, 25);
            txtLN.TabIndex = 2;
            txtLN.Text = "Last Name";
            // 
            // txtDoB
            // 
            txtDoB.AutoSize = true;
            txtDoB.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            txtDoB.Location = new Point(8, 304);
            txtDoB.Name = "txtDoB";
            txtDoB.Size = new Size(119, 25);
            txtDoB.TabIndex = 3;
            txtDoB.Text = "Date of Birth";
            // 
            // txtAddr
            // 
            txtAddr.AutoSize = true;
            txtAddr.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            txtAddr.Location = new Point(12, 355);
            txtAddr.Name = "txtAddr";
            txtAddr.Size = new Size(79, 25);
            txtAddr.TabIndex = 4;
            txtAddr.Text = "Address";
            // 
            // txtPh
            // 
            txtPh.AutoSize = true;
            txtPh.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            txtPh.Location = new Point(12, 410);
            txtPh.Name = "txtPh";
            txtPh.Size = new Size(65, 25);
            txtPh.TabIndex = 5;
            txtPh.Text = "Phone";
            // 
            // txtStudentID
            // 
            txtStudentID.Location = new Point(150, 115);
            txtStudentID.Margin = new Padding(3, 4, 3, 4);
            txtStudentID.Name = "txtStudentID";
            txtStudentID.Size = new Size(214, 27);
            txtStudentID.TabIndex = 6;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(150, 179);
            txtFirstName.Margin = new Padding(3, 4, 3, 4);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(214, 27);
            txtFirstName.TabIndex = 7;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(150, 246);
            txtLastName.Margin = new Padding(3, 4, 3, 4);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(214, 27);
            txtLastName.TabIndex = 8;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(149, 355);
            txtAddress.Margin = new Padding(3, 4, 3, 4);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(180, 27);
            txtAddress.TabIndex = 9;
            txtAddress.TextChanged += txtAddress_TextChanged;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(149, 408);
            txtPhone.Margin = new Padding(3, 4, 3, 4);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(214, 27);
            txtPhone.TabIndex = 10;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(192, 192, 0);
            panel1.Controls.Add(label7);
            panel1.Location = new Point(2, 3);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(815, 89);
            panel1.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Centaur", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(299, 31);
            label7.Name = "label7";
            label7.Size = new Size(252, 31);
            label7.TabIndex = 0;
            label7.Text = "Student's Information";
            // 
            // pictureBox
            // 
            pictureBox.BackColor = SystemColors.ActiveBorder;
            pictureBox.Image = (Image)resources.GetObject("pictureBox.Image");
            pictureBox.Location = new Point(422, 117);
            pictureBox.Margin = new Padding(3, 4, 3, 4);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(225, 263);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.TabIndex = 14;
            pictureBox.TabStop = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(192, 192, 0);
            btnInsert.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.Location = new Point(669, 324);
            btnInsert.Margin = new Padding(3, 4, 3, 4);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(139, 58);
            btnInsert.TabIndex = 16;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            btnInsert.Click += btninsert_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(192, 192, 0);
            btnUpdate.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.Location = new Point(669, 255);
            btnUpdate.Margin = new Padding(3, 4, 3, 4);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(139, 61);
            btnUpdate.TabIndex = 17;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnupdate_Click;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(192, 192, 0);
            btnClear.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.Location = new Point(669, 115);
            btnClear.Margin = new Padding(3, 4, 3, 4);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(139, 68);
            btnClear.TabIndex = 18;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnclear_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(192, 192, 0);
            btnDelete.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnDelete.Location = new Point(669, 191);
            btnDelete.Margin = new Padding(3, 4, 3, 4);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(139, 56);
            btnDelete.TabIndex = 19;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btndelete_Click;
            // 
            // btnback
            // 
            btnback.BackColor = Color.Lime;
            btnback.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnback.Location = new Point(507, 704);
            btnback.Margin = new Padding(3, 4, 3, 4);
            btnback.Name = "btnback";
            btnback.Size = new Size(139, 42);
            btnback.TabIndex = 20;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = false;
            btnback.Click += btnback_Click;
            // 
            // btnlogout
            // 
            btnlogout.BackColor = Color.Red;
            btnlogout.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnlogout.Location = new Point(652, 704);
            btnlogout.Margin = new Padding(3, 4, 3, 4);
            btnlogout.Name = "btnlogout";
            btnlogout.Size = new Size(139, 42);
            btnlogout.TabIndex = 21;
            btnlogout.Text = "Log out";
            btnlogout.UseVisualStyleBackColor = false;
            btnlogout.Click += button6_Click;
            // 
            // dtpDateOfBirth
            // 
            dtpDateOfBirth.Location = new Point(150, 302);
            dtpDateOfBirth.Margin = new Padding(3, 4, 3, 4);
            dtpDateOfBirth.Name = "dtpDateOfBirth";
            dtpDateOfBirth.Size = new Size(266, 27);
            dtpDateOfBirth.TabIndex = 22;
            dtpDateOfBirth.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // dataGridViewStudents
            // 
            dataGridViewStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewStudents.Location = new Point(28, 454);
            dataGridViewStudents.Name = "dataGridViewStudents";
            dataGridViewStudents.RowHeadersWidth = 51;
            dataGridViewStudents.RowTemplate.Height = 29;
            dataGridViewStudents.Size = new Size(780, 243);
            dataGridViewStudents.TabIndex = 23;
            dataGridViewStudents.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // btnBrowse
            // 
            btnBrowse.BackColor = Color.Silver;
            btnBrowse.Location = new Point(465, 388);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(108, 47);
            btnBrowse.TabIndex = 24;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = false;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(820, 759);
            Controls.Add(btnBrowse);
            Controls.Add(dataGridViewStudents);
            Controls.Add(dtpDateOfBirth);
            Controls.Add(btnlogout);
            Controls.Add(btnback);
            Controls.Add(btnDelete);
            Controls.Add(btnClear);
            Controls.Add(btnUpdate);
            Controls.Add(btnInsert);
            Controls.Add(pictureBox);
            Controls.Add(panel1);
            Controls.Add(txtPhone);
            Controls.Add(txtAddress);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(txtStudentID);
            Controls.Add(txtPh);
            Controls.Add(txtAddr);
            Controls.Add(txtDoB);
            Controls.Add(txtLN);
            Controls.Add(txtFN);
            Controls.Add(txtstuID);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudents).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label txtstuID;
        private Label txtFN;
        private Label txtLN;
        private Label txtDoB;
        private Label txtAddr;
        private Label txtPh;
        private TextBox txtStudentID;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private TextBox txtAddress;
        private TextBox txtPhone;
        private Panel panel1;
        private Label label7;
        private PictureBox pictureBox;
        private Button btnInsert;
        private Button btnUpdate;
        private Button btnClear;
        private Button btnDelete;
        private Button btnback;
        private Button btnlogout;
        private DateTimePicker dtpDateOfBirth;
        private DataGridView dataGridViewStudents;
        private Button btnBrowse;
    }
}