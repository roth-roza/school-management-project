﻿namespace school_management
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnLogin = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            label13 = new Label();
            txtUserName = new TextBox();
            label3 = new Label();
            txtPassword = new TextBox();
            label2 = new Label();
            ckShow = new CheckBox();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // btnLogin
            // 
            btnLogin.BackColor = SystemColors.ActiveCaption;
            btnLogin.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogin.ForeColor = Color.Black;
            btnLogin.Location = new Point(362, 192);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(94, 37);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Login ";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.White;
            label13.Location = new Point(147, 3);
            label13.Name = "label13";
            label13.Size = new Size(179, 39);
            label13.TabIndex = 2;
            label13.Text = "Login Form";
            label13.Click += label13_Click;
            // 
            // txtUserName
            // 
            txtUserName.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtUserName.Location = new Point(204, 89);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(252, 27);
            txtUserName.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(32, 95);
            label3.Name = "label3";
            label3.Size = new Size(104, 20);
            label3.TabIndex = 12;
            label3.Text = "User Name :";
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.Location = new Point(204, 132);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(252, 27);
            txtPassword.TabIndex = 27;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(32, 138);
            label2.Name = "label2";
            label2.Size = new Size(93, 20);
            label2.TabIndex = 26;
            label2.Text = "Password :";
            // 
            // ckShow
            // 
            ckShow.AutoSize = true;
            ckShow.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            ckShow.Location = new Point(231, 165);
            ckShow.Name = "ckShow";
            ckShow.Size = new Size(137, 23);
            ckShow.TabIndex = 28;
            ckShow.Text = "Show Password";
            ckShow.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label13);
            panel1.Location = new Point(-1, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(495, 46);
            panel1.TabIndex = 29;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Draft_Logo;
            pictureBox2.Location = new Point(13, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(59, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 30;
            pictureBox2.TabStop = false;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SeaShell;
            ClientSize = new Size(493, 269);
            Controls.Add(panel1);
            Controls.Add(ckShow);
            Controls.Add(txtPassword);
            Controls.Add(label2);
            Controls.Add(txtUserName);
            Controls.Add(label3);
            Controls.Add(btnLogin);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login Form";
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Button btnLogin;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
        private Label label13;
        private TextBox txtUserName;
        private Label label3;
        private TextBox txtPassword;
        private Label label2;
        private CheckBox ckShow;
        private Panel panel1;
        private PictureBox pictureBox2;
    }
}