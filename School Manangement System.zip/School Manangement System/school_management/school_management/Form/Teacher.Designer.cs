﻿namespace school_management
{
    partial class Teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            groupBox1 = new GroupBox();
            textSearch = new TextBox();
            lblsearch = new Label();
            btnlogout = new Button();
            btnClear = new Button();
            btndelete = new Button();
            btnupdate = new Button();
            btnadd = new Button();
            btnPhoto = new Button();
            btnback = new Button();
            pbTeacher = new PictureBox();
            textEmail = new TextBox();
            textPhoneNumber = new TextBox();
            textLastName = new TextBox();
            textFirstName = new TextBox();
            textTeacherID = new TextBox();
            lblemail = new Label();
            lblphone = new Label();
            lblsubjectid = new Label();
            lbllastname = new Label();
            lblfirstname = new Label();
            lblteacherid = new Label();
            dataGridViewTeachers = new DataGridView();
            cbSubject = new ComboBox();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbTeacher).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTeachers).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(894, 42);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(389, 6);
            label1.Name = "label1";
            label1.Size = new Size(94, 26);
            label1.TabIndex = 0;
            label1.Text = "Teacher";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            groupBox1.Controls.Add(cbSubject);
            groupBox1.Controls.Add(textSearch);
            groupBox1.Controls.Add(lblsearch);
            groupBox1.Controls.Add(btnlogout);
            groupBox1.Controls.Add(btnClear);
            groupBox1.Controls.Add(btndelete);
            groupBox1.Controls.Add(btnupdate);
            groupBox1.Controls.Add(btnadd);
            groupBox1.Controls.Add(btnPhoto);
            groupBox1.Controls.Add(btnback);
            groupBox1.Controls.Add(pbTeacher);
            groupBox1.Controls.Add(textEmail);
            groupBox1.Controls.Add(textPhoneNumber);
            groupBox1.Controls.Add(textLastName);
            groupBox1.Controls.Add(textFirstName);
            groupBox1.Controls.Add(textTeacherID);
            groupBox1.Controls.Add(lblemail);
            groupBox1.Controls.Add(lblphone);
            groupBox1.Controls.Add(lblsubjectid);
            groupBox1.Controls.Add(lbllastname);
            groupBox1.Controls.Add(lblfirstname);
            groupBox1.Controls.Add(lblteacherid);
            groupBox1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(0, 48);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(888, 488);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Teacher's Information";
            // 
            // textSearch
            // 
            textSearch.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textSearch.Location = new Point(583, 31);
            textSearch.Name = "textSearch";
            textSearch.Size = new Size(288, 30);
            textSearch.TabIndex = 20;
            textSearch.TextChanged += textSearch_TextChanged;

            // 
            // lblsearch
            // 
            lblsearch.AutoSize = true;
            lblsearch.Location = new Point(497, 37);
            lblsearch.Name = "lblsearch";
            lblsearch.Size = new Size(64, 22);
            lblsearch.TabIndex = 19;
            lblsearch.Text = "Search";
            // 
            // btnlogout
            // 
            btnlogout.BackColor = SystemColors.ActiveCaption;
            btnlogout.Location = new Point(781, 424);
            btnlogout.Name = "btnlogout";
            btnlogout.Size = new Size(101, 52);
            btnlogout.TabIndex = 17;
            btnlogout.Text = "Logout";
            btnlogout.UseVisualStyleBackColor = false;
            btnlogout.Click += btnlogout_Click;
            // 
            // btnClear
            // 
            btnClear.BackColor = SystemColors.ActiveCaption;
            btnClear.Location = new Point(363, 425);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(101, 52);
            btnClear.TabIndex = 16;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // btndelete
            // 
            btndelete.BackColor = SystemColors.ActiveCaption;
            btndelete.Location = new Point(256, 424);
            btndelete.Name = "btndelete";
            btndelete.Size = new Size(101, 52);
            btndelete.TabIndex = 16;
            btndelete.Text = "Delete";
            btndelete.UseVisualStyleBackColor = false;
            btndelete.Click += btndelete_Click;
            // 
            // btnupdate
            // 
            btnupdate.BackColor = SystemColors.ActiveCaption;
            btnupdate.Location = new Point(151, 424);
            btnupdate.Name = "btnupdate";
            btnupdate.Size = new Size(101, 52);
            btnupdate.TabIndex = 15;
            btnupdate.Text = "Update";
            btnupdate.UseVisualStyleBackColor = false;
            btnupdate.Click += btnupdate_Click;
            // 
            // btnadd
            // 
            btnadd.BackColor = SystemColors.ActiveCaption;
            btnadd.Location = new Point(45, 424);
            btnadd.Name = "btnadd";
            btnadd.Size = new Size(101, 52);
            btnadd.TabIndex = 14;
            btnadd.Text = "Add";
            btnadd.UseVisualStyleBackColor = false;
            btnadd.Click += btnadd_Click;
            // 
            // btnPhoto
            // 
            btnPhoto.BackColor = SystemColors.ActiveCaption;
            btnPhoto.Location = new Point(626, 359);
            btnPhoto.Name = "btnPhoto";
            btnPhoto.Size = new Size(150, 32);
            btnPhoto.TabIndex = 13;
            btnPhoto.Text = "Photo";
            btnPhoto.UseVisualStyleBackColor = false;
            btnPhoto.Click += btnPhoto_Click;
            // 
            // btnback
            // 
            btnback.BackColor = SystemColors.ActiveCaption;
            btnback.Location = new Point(675, 424);
            btnback.Name = "btnback";
            btnback.Size = new Size(101, 52);
            btnback.TabIndex = 13;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = false;
            btnback.Click += btnback_Click;
            // 
            // pbTeacher
            // 
            pbTeacher.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pbTeacher.InitialImage = null;
            pbTeacher.Location = new Point(502, 84);
            pbTeacher.Name = "pbTeacher";
            pbTeacher.Size = new Size(369, 265);
            pbTeacher.SizeMode = PictureBoxSizeMode.StretchImage;
            pbTeacher.TabIndex = 12;
            pbTeacher.TabStop = false;
            // 
            // textEmail
            // 
            textEmail.Location = new Point(174, 351);
            textEmail.Name = "textEmail";
            textEmail.Size = new Size(299, 30);
            textEmail.TabIndex = 11;
            // 
            // textPhoneNumber
            // 
            textPhoneNumber.Location = new Point(174, 280);
            textPhoneNumber.Name = "textPhoneNumber";
            textPhoneNumber.Size = new Size(299, 30);
            textPhoneNumber.TabIndex = 10;
            // 
            // textLastName
            // 
            textLastName.Location = new Point(174, 153);
            textLastName.Name = "textLastName";
            textLastName.Size = new Size(299, 30);
            textLastName.TabIndex = 8;
            // 
            // textFirstName
            // 
            textFirstName.Location = new Point(174, 88);
            textFirstName.Name = "textFirstName";
            textFirstName.Size = new Size(299, 30);
            textFirstName.TabIndex = 7;
            // 
            // textTeacherID
            // 
            textTeacherID.Location = new Point(174, 34);
            textTeacherID.Name = "textTeacherID";
            textTeacherID.Size = new Size(299, 30);
            textTeacherID.TabIndex = 6;
            // 
            // lblemail
            // 
            lblemail.AutoSize = true;
            lblemail.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lblemail.Location = new Point(99, 358);
            lblemail.Name = "lblemail";
            lblemail.Size = new Size(54, 19);
            lblemail.TabIndex = 5;
            lblemail.Text = "Email:";
            // 
            // lblphone
            // 
            lblphone.AutoSize = true;
            lblphone.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lblphone.Location = new Point(42, 293);
            lblphone.Name = "lblphone";
            lblphone.Size = new Size(112, 19);
            lblphone.TabIndex = 4;
            lblphone.Text = "Phone number:";
            // 
            // lblsubjectid
            // 
            lblsubjectid.AutoSize = true;
            lblsubjectid.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lblsubjectid.Location = new Point(66, 230);
            lblsubjectid.Name = "lblsubjectid";
            lblsubjectid.Size = new Size(86, 19);
            lblsubjectid.TabIndex = 3;
            lblsubjectid.Text = "Subject ID:";
            // 
            // lbllastname
            // 
            lbllastname.AutoSize = true;
            lbllastname.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lbllastname.Location = new Point(66, 166);
            lbllastname.Name = "lbllastname";
            lbllastname.Size = new Size(87, 19);
            lbllastname.TabIndex = 2;
            lbllastname.Text = "Last Name:";
            // 
            // lblfirstname
            // 
            lblfirstname.AutoSize = true;
            lblfirstname.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lblfirstname.Location = new Point(62, 101);
            lblfirstname.Name = "lblfirstname";
            lblfirstname.Size = new Size(90, 19);
            lblfirstname.TabIndex = 1;
            lblfirstname.Text = "First Name:";
            // 
            // lblteacherid
            // 
            lblteacherid.AutoSize = true;
            lblteacherid.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lblteacherid.Location = new Point(62, 44);
            lblteacherid.Name = "lblteacherid";
            lblteacherid.Size = new Size(88, 19);
            lblteacherid.TabIndex = 0;
            lblteacherid.Text = "Teacher ID:";
            // 
            // dataGridViewTeachers
            // 
            dataGridViewTeachers.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewTeachers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewTeachers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTeachers.Location = new Point(0, 531);
            dataGridViewTeachers.Name = "dataGridViewTeachers";
            dataGridViewTeachers.RowHeadersWidth = 62;
            dataGridViewTeachers.RowTemplate.Height = 28;
            dataGridViewTeachers.Size = new Size(879, 192);
            dataGridViewTeachers.TabIndex = 2;
            dataGridViewTeachers.CellClick += dataGridViewTeachers_CellClick;
            // 
            // cbSubject
            // 
            cbSubject.FormattingEnabled = true;
            cbSubject.Location = new Point(174, 222);
            cbSubject.Name = "cbSubject";
            cbSubject.Size = new Size(299, 30);
            cbSubject.TabIndex = 21;
            // 
            // Teacher
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(894, 765);
            Controls.Add(dataGridViewTeachers);
            Controls.Add(groupBox1);
            Controls.Add(panel1);
            Name = "Teacher";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Teacher";
            Load += Teacher_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbTeacher).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTeachers).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.TextBox textPhoneNumber;
        private System.Windows.Forms.TextBox textLastName;
        private System.Windows.Forms.TextBox textFirstName;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lblsubjectid;
        private System.Windows.Forms.Label lbllastname;
        private System.Windows.Forms.Label lblfirstname;
        private System.Windows.Forms.PictureBox pbTeacher;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.DataGridView dataGridViewTeachers;
        private System.Windows.Forms.TextBox textSearch;
        private System.Windows.Forms.Label lblsearch;
        private Button btnPhoto;
        private Button btnClear;
        private TextBox textTeacherID;
        private Label lblteacherid;
        private ComboBox cbSubject;
    }

}