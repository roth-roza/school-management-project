﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace school_management
{
    public partial class Teacher : Form
    {
        private readonly string connectionString = "Data Source=MSI-ROZA\\SQLEXPRESS1;Initial Catalog=school2_db;Integrated Security=True;TrustServerCertificate=True";

        public Teacher()
        {
            InitializeComponent();
            LoadSubjects(); // Load subjects into ComboBox
        }

        private void Teacher_Load(object sender, EventArgs e)
        {
            dataGridViewTeachers.AllowUserToAddRows = false;
            LoadTeacher();
        }

        private void LoadSubjects()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT subject_id, subject_name FROM Subjects";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                cbSubject.DataSource = dataTable;
                cbSubject.DisplayMember = "subject_name";
                cbSubject.ValueMember = "subject_id";
                cbSubject.SelectedIndex = -1; // Initially no selection
            }
        }

        private void LoadTeacher()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT teacher_id, first_name, last_name, subject_id, phone_number, email, photo FROM Teachers";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Clear existing rows, but only clear columns once.
                dataGridViewTeachers.Rows.Clear();

                if (dataGridViewTeachers.Columns.Count == 0) // Ensure columns are added only once.
                {
                    dataGridViewTeachers.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = "teacher_id",
                        DataPropertyName = "teacher_id",
                        HeaderText = "ID"
                    });
                    dataGridViewTeachers.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = "first_name",
                        DataPropertyName = "first_name",
                        HeaderText = "First Name"
                    });
                    dataGridViewTeachers.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = "last_name",
                        DataPropertyName = "last_name",
                        HeaderText = "Last Name"
                    });
                    dataGridViewTeachers.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = "subject_id",
                        DataPropertyName = "subject_id",
                        HeaderText = "Subject ID"
                    });
                    dataGridViewTeachers.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = "phone_number",
                        DataPropertyName = "phone_number",
                        HeaderText = "Phone Number"
                    });
                    dataGridViewTeachers.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = "email",
                        DataPropertyName = "email",
                        HeaderText = "Email"
                    });

                    DataGridViewImageColumn imageColumn = new DataGridViewImageColumn
                    {
                        Name = "photo",
                        HeaderText = "Photo",
                        ImageLayout = DataGridViewImageCellLayout.Zoom
                    };
                    dataGridViewTeachers.Columns.Add(imageColumn);
                }

                // Populate DataGridView Rows
                foreach (DataRow row in dataTable.Rows)
                {
                    object photoObj = row["photo"];
                    Image photoImage = null;

                    try
                    {
                        if (photoObj != DBNull.Value && photoObj is byte[] photoBytes && photoBytes.Length > 0)
                        {
                            using (var ms = new MemoryStream(photoBytes))
                            {
                                photoImage = Image.FromStream(ms);
                            }
                        }
                    }
                    catch
                    {
                        photoImage = null;
                    }

                    dataGridViewTeachers.Rows.Add(
                        row["teacher_id"],
                        row["first_name"],
                        row["last_name"],
                        row["subject_id"],
                        row["phone_number"],
                        row["email"],
                        photoImage
                    );
                }
            }
        }
        private void SearchTeacher()
        {
            // Get the search term from a TextBox (e.g., textSearch)
            string searchTerm = textSearch.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Modify the query to filter based on search term
                string query = "SELECT teacher_id, first_name, last_name, subject_id, phone_number, email, photo " +
                               "FROM Teachers WHERE first_name LIKE @SearchTerm OR last_name LIKE @SearchTerm";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Clear existing rows in the DataGridView before adding new ones
                dataGridViewTeachers.Rows.Clear();

                // Populate the DataGridView with the search results
                foreach (DataRow row in dataTable.Rows)
                {
                    object photoObj = row["photo"];
                    Image photoImage = null;

                    try
                    {
                        if (photoObj != DBNull.Value && photoObj is byte[] photoBytes && photoBytes.Length > 0)
                        {
                            using (var ms = new MemoryStream(photoBytes))
                            {
                                photoImage = Image.FromStream(ms);
                            }
                        }
                    }
                    catch
                    {
                        photoImage = null; // Fallback to null if the image is invalid
                    }

                    dataGridViewTeachers.Rows.Add(
                        row["teacher_id"],
                        row["first_name"],
                        row["last_name"],
                        row["subject_id"],
                        row["phone_number"],
                        row["email"],
                        photoImage
                    );
                }
            }
        }

        private void AddTeacher()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Teachers (first_name, last_name, subject_id, phone_number, email, photo) " +
                               "VALUES (@FirstName, @LastName, @SubjectID, @PhoneNumber, @Email, @Photo)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@FirstName", textFirstName.Text);
                command.Parameters.AddWithValue("@LastName", textLastName.Text);
                command.Parameters.AddWithValue("@SubjectID", cbSubject.SelectedValue ?? DBNull.Value);
                command.Parameters.AddWithValue("@PhoneNumber", textPhoneNumber.Text);
                command.Parameters.AddWithValue("@Email", textEmail.Text);

                if (pbTeacher.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        pbTeacher.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        command.Parameters.AddWithValue("@Photo", ms.ToArray());
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("@Photo", DBNull.Value);
                }

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Teacher added successfully.");
                LoadTeacher();
            }
        }
        private void UpdateTeacher()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"
        UPDATE Teachers 
        SET 
            first_name = @FirstName, 
            last_name = @LastName, 
            subject_id = @SubjectID, 
            phone_number = @PhoneNumber, 
            email = @Email, 
            photo = @Photo 
        WHERE 
            teacher_id = @TeacherID";

                SqlCommand command = new SqlCommand(query, connection);

                // Ensure TeacherID is passed as an integer
                if (int.TryParse(textTeacherID.Text, out int teacherId))
                {
                    command.Parameters.AddWithValue("@TeacherID", teacherId);
                }
                else
                {
                    MessageBox.Show("Invalid Teacher ID.");
                    return;
                }

                // Add other parameters
                command.Parameters.AddWithValue("@FirstName", textFirstName.Text);
                command.Parameters.AddWithValue("@LastName", textLastName.Text);
                command.Parameters.AddWithValue("@SubjectID", cbSubject.SelectedValue);
                command.Parameters.AddWithValue("@PhoneNumber", textPhoneNumber.Text);
                command.Parameters.AddWithValue("@Email", textEmail.Text);

                // Handle Photo - Convert image to binary if present
                if (pbTeacher.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        try
                        {
                            var imgCopy = (Image)pbTeacher.Image.Clone(); // Clone image to avoid GDI+ lock issues
                            imgCopy.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            ms.Position = 0; // Reset the stream position to the beginning
                            command.Parameters.AddWithValue("@Photo", ms.ToArray());
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Image save error: {ex.Message}");
                            return;
                        }
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("@Photo", DBNull.Value);
                }

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Teacher updated successfully.");
                        LoadTeacher(); // Refresh the DataGridView
                    }
                    else
                    {
                        MessageBox.Show("No matching teacher found to update.");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Database error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Unexpected error: {ex.Message}");
                }
            }
        }


        private void DeleteTeacher()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Teachers WHERE teacher_id = @TeacherID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TeacherID", textTeacherID.Text);

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Teacher deleted successfully.");
                LoadTeacher();
            }
        }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pbTeacher.Image = Image.FromFile(openFileDialog.FileName);
            }
        }

        private void btnadd_Click(object sender, EventArgs e) => AddTeacher();
        private void btnupdate_Click(object sender, EventArgs e) => UpdateTeacher();
        private void btndelete_Click(object sender, EventArgs e) => DeleteTeacher();

        private void btnlogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide(); // Hide the current form
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide(); // Hide the current form
        }

        private void dataGridViewTeachers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridViewTeachers.Rows[e.RowIndex];

                textTeacherID.Text = selectedRow.Cells["teacher_id"].Value?.ToString();
                textFirstName.Text = selectedRow.Cells["first_name"].Value?.ToString();
                textLastName.Text = selectedRow.Cells["last_name"].Value?.ToString();
                cbSubject.SelectedValue = selectedRow.Cells["subject_id"].Value;
                textPhoneNumber.Text = selectedRow.Cells["phone_number"].Value?.ToString();
                textEmail.Text = selectedRow.Cells["email"].Value?.ToString();

                if (selectedRow.Cells["photo"].Value is Image photo)
                {
                    pbTeacher.Image = photo;
                }
                else
                {
                    pbTeacher.Image = null;
                }
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear all text fields
            textTeacherID.Clear();
            textFirstName.Clear();
            textLastName.Clear();
            textPhoneNumber.Clear();
            textEmail.Clear();

            // Reset ComboBox selection
            cbSubject.SelectedIndex = -1; // Clears selection in ComboBox

            // Clear the PictureBox
            pbTeacher.Image = null;

            // Optionally clear focus or set focus to the first input
            textFirstName.Focus();
        }
        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            SearchTeacher();
        }


    }
}
