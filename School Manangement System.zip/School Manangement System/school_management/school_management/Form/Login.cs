﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace school_management
{
    public partial class Login : Form
    {
        // Connection string to the SQL Server database
        private string connectionString = "Data Source=MSI-ROZA\\SQLEXPRESS1;Initial Catalog=school2_db;Integrated Security=True;TrustServerCertificate=True";

        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Get username and password from the textboxes
            string username = txtUserName.Text;
            string password = txtPassword.Text;

            // Validate credentials
            if (ValidateUser(username, password))
            {
                // Show success message and navigate to Form1
                MessageBox.Show("Login successful!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Dashboard mainForm = new Dashboard();
                mainForm.Show();
                this.Hide(); // Hide the login form
            }
            else
            {
                // Show error message
                MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateUser(string username, string password)
        {
            // Connect to the SQL Server database and check the credentials
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    // Execute the query and check if the user exists
                    int userCount = Convert.ToInt32(cmd.ExecuteScalar());
                    return userCount > 0;
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
