﻿namespace school_management
{
    partial class score_management
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(score_management));
            label1 = new Label();
            label5 = new Label();
            label6 = new Label();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox4 = new PictureBox();
            label3 = new Label();
            btnBack = new Button();
            txtScore = new TextBox();
            label2 = new Label();
            txtStuID = new TextBox();
            picStudent = new PictureBox();
            cbStuName = new ComboBox();
            cbSubject = new ComboBox();
            dgvStu = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picStudent).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvStu).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(21, 130);
            label1.Name = "label1";
            label1.Size = new Size(116, 19);
            label1.TabIndex = 0;
            label1.Text = "Select Subject :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(21, 161);
            label5.Name = "label5";
            label5.Size = new Size(90, 19);
            label5.TabIndex = 0;
            label5.Text = "Student ID :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(22, 221);
            label6.Name = "label6";
            label6.Size = new Size(58, 19);
            label6.TabIndex = 0;
            label6.Text = "Score :";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(547, 473);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(285, 473);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(154, 473);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdateScore_Click;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(12, 473);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            btnInsert.Click += btnAddScore_Click;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Controls.Add(pictureBox4);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(660, 76);
            panel2.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(178, 9);
            label13.Name = "label13";
            label13.Size = new Size(401, 39);
            label13.TabIndex = 2;
            label13.Text = "School Management System";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(214, 56);
            label12.Name = "label12";
            label12.Size = new Size(237, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright OOAD_M3_Group12(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(178, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(255, 255, 128);
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(0, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(163, 76);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 30;
            pictureBox4.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(21, 192);
            label3.Name = "label3";
            label3.Size = new Size(113, 19);
            label3.TabIndex = 12;
            label3.Text = "Student Name :";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(419, 473);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // txtScore
            // 
            txtScore.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtScore.Location = new Point(140, 218);
            txtScore.Name = "txtScore";
            txtScore.Size = new Size(252, 27);
            txtScore.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(22, 151);
            label2.Name = "label2";
            label2.Size = new Size(0, 19);
            label2.TabIndex = 26;
            // 
            // txtStuID
            // 
            txtStuID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtStuID.Location = new Point(140, 155);
            txtStuID.Name = "txtStuID";
            txtStuID.Size = new Size(252, 27);
            txtStuID.TabIndex = 31;
            txtStuID.Leave += txtStuID_Leave;
            // 
            // picStudent
            // 
            picStudent.BackColor = SystemColors.ButtonHighlight;
            picStudent.Location = new Point(454, 110);
            picStudent.Name = "picStudent";
            picStudent.Size = new Size(161, 147);
            picStudent.SizeMode = PictureBoxSizeMode.StretchImage;
            picStudent.TabIndex = 33;
            picStudent.TabStop = false;
            // 
            // cbStuName
            // 
            cbStuName.FormattingEnabled = true;
            cbStuName.Location = new Point(140, 186);
            cbStuName.Name = "cbStuName";
            cbStuName.Size = new Size(252, 25);
            cbStuName.TabIndex = 50;
            cbStuName.SelectedIndexChanged += cbStuName_SelectedIndexChanged;
            // 
            // cbSubject
            // 
            cbSubject.FormattingEnabled = true;
            cbSubject.Location = new Point(140, 124);
            cbSubject.Name = "cbSubject";
            cbSubject.Size = new Size(252, 25);
            cbSubject.TabIndex = 51;
            cbSubject.SelectedIndexChanged += CbSubject_SelectedIndexChanged;
            // 
            // dgvStu
            // 
            dgvStu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStu.Location = new Point(12, 263);
            dgvStu.Name = "dgvStu";
            dgvStu.RowHeadersWidth = 51;
            dgvStu.RowTemplate.Height = 29;
            dgvStu.Size = new Size(629, 188);
            dgvStu.TabIndex = 52;
            dgvStu.CellClick += dgvStu_CellClick;
            // 
            // score_management
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(660, 522);
            Controls.Add(dgvStu);
            Controls.Add(cbSubject);
            Controls.Add(cbStuName);
            Controls.Add(picStudent);
            Controls.Add(txtStuID);
            Controls.Add(txtScore);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(label3);
            Controls.Add(panel2);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            Name = "score_management";
            Text = "School Management System";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)picStudent).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvStu).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void cbSubject_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private Label label1;
        private Label label5;
        private Label label6;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private Label label3;
        private Button btnBack;
        private TextBox txtScore;
        private Label label2;
        private PictureBox pictureBox4;
        private TextBox txtStuID;
        private PictureBox picStudent;
        private ComboBox cbStuName;
        private ComboBox cbSubject;
        private DataGridView dgvStu;
    }
}
