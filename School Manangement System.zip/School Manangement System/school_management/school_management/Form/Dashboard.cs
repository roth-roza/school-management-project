﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace school_management
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            // Open the Score Management Form
            Teacher Teachers = new Teacher();
            Teachers.Show();
            this.Hide(); // Hide the login form
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btnScore_Click(object sender, EventArgs e)
        {
            // Open the Score Management Form
            score_management scoreForm = new score_management();
            scoreForm.Show();
            this.Hide(); // Hide the login form
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Login LoginForm = new Login();
            LoginForm.Show();
            this.Hide(); // Hide the login form
        }

        private void btnScore_Click_1(object sender, EventArgs e)
        {
            score_management ScoreForm = new score_management();
            ScoreForm.Show();
            this.Hide(); // Hide the login form
        }

        private void btnTeacher_Click(object sender, EventArgs e)
        {
            Teacher Teacher = new Teacher();
            Teacher.Show();
            this.Hide(); // Hide the login form
        }

        private void btnClassroom_Click(object sender, EventArgs e)
        {
            classroom classrrom = new classroom();
            classrrom.Show();
            this.Hide(); // Hide the login form
        }

        private void btnStudent_Click(object sender, EventArgs e)
        {
            student student = new student();
            student.Show();
            this.Hide(); // Hide the login form
        }
    }
}
