using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
namespace school_management;

public partial class score_management : Form
{
    private readonly DatabaseHelper _databaseHelper;
    private readonly StudentManager _studentManager;
    private readonly SubjectManager _subjectManager;
    private readonly ScoreManager _scoreManager;

    public score_management()
    {
        InitializeComponent();

        // Instantiate the helper and managers
        string connectionString = "Data Source=MSI-ROZA\\SQLEXPRESS1;Initial Catalog=school2_db;Integrated Security=True;TrustServerCertificate=True";
        _databaseHelper = new DatabaseHelper(connectionString);
        _studentManager = new StudentManager(_databaseHelper);
        _subjectManager = new SubjectManager(_databaseHelper);
        _scoreManager = new ScoreManager(_databaseHelper);
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        dgvStu.Columns.Clear();
        dgvStu.RowHeadersVisible = false;
        dgvStu.BorderStyle = BorderStyle.Fixed3D;
        dgvStu.DefaultCellStyle.Font = new Font("Times New Roman", 10);
        dgvStu.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 10, FontStyle.Bold);

        _subjectManager.LoadSubjects(cbSubject);
        _studentManager.PopulateStudentNames(cbStuName);
        _studentManager.LoadStudentScores(dgvStu);
    }

    private void txtStuID_Leave(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(txtStuID.Text))
        {
            _studentManager.FetchStudentDetails(txtStuID.Text.Trim(), cbStuName, picStudent);
        }
        else
        {
            cbStuName.Text = "";
            picStudent.Image = null;
        }
    }

    private void cbStuName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (cbStuName.SelectedValue is string selectedStudentId)
        {
            // Fetch and display the student details
            _studentManager.FetchStudentDetails(selectedStudentId, cbStuName, picStudent);

            // Update the txtStuID based on the selected name
            txtStuID.Text = selectedStudentId;

            // Fetch and display the score for the currently selected subject
            if (cbSubject.SelectedValue != null)
            {
                string subjectId = cbSubject.SelectedValue.ToString();
                _scoreManager.FetchStudentScore(selectedStudentId, subjectId, txtScore);
            }
        }
    }
    private void CbSubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(txtStuID.Text) && cbSubject.SelectedValue != null)
        {
            string studentId = txtStuID.Text.Trim(); // Get the Student ID
            string subjectId = cbSubject.SelectedValue.ToString(); // Get the Subject ID

            // Fetch the score for the selected student and subject
            _scoreManager.FetchStudentScore(studentId, subjectId, txtScore);
        }
    }

    private void btnAddScore_Click(object sender, EventArgs e)
    {
        if (ValidateScoreInput(out string studentCode, out string subjectId, out float score))
        {
            _scoreManager.InsertStudentScore(studentCode, subjectId, score, dgvStu);
        }
    }

    private void btnUpdateScore_Click(object sender, EventArgs e)
    {
        if (ValidateScoreInput(out string studentId, out string subjectId, out float score))
        {
            _scoreManager.UpdateStudentScore(studentId, subjectId, score, dgvStu);
        }
    }

    private void dgvStu_CellClick(object sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex >= 0) // Ensure it's not a header row
        {
            // Get the selected row
            DataGridViewRow selectedRow = dgvStu.Rows[e.RowIndex];

            // Extract the student ID
            string studentId = selectedRow.Cells["StudentID"].Value?.ToString();
            txtStuID.Text = studentId;

            // Extract the student name
            string studentName = selectedRow.Cells["StudentName"].Value?.ToString();
            cbStuName.Text = studentName;

            // Determine the subject and score based on the row's data
            string mathScore = selectedRow.Cells["MathScore"].Value?.ToString();
            string scienceScore = selectedRow.Cells["ScienceScore"].Value?.ToString();
            string historyScore = selectedRow.Cells["HistoryScore"].Value?.ToString();

            // Update the subject and score fields based on the first non-null score
            if (!string.IsNullOrEmpty(mathScore))
            {
                cbSubject.SelectedValue = "1"; // Assuming "1" is the subject_id for Mathematics
                txtScore.Text = mathScore;
            }
            else if (!string.IsNullOrEmpty(scienceScore))
            {
                cbSubject.SelectedValue = "2"; // Assuming "2" is the subject_id for Science
                txtScore.Text = scienceScore;
            }
            else if (!string.IsNullOrEmpty(historyScore))
            {
                cbSubject.SelectedValue = "3"; // Assuming "3" is the subject_id for History
                txtScore.Text = historyScore;
            }
            else
            {
                // Clear the score and subject if no scores are found
                txtScore.Clear();
                cbSubject.SelectedIndex = -1;
            }
        }
    }

    private void btnClear_Click(object sender, EventArgs e)
    {
        txtStuID.Clear();
        cbStuName.SelectedIndex = -1;
        cbSubject.SelectedIndex = -1;
        txtScore.Clear();
        picStudent.Image = null;
    }

    private bool ValidateScoreInput(out string studentCode, out string subjectId, out float score)
    {
        studentCode = txtStuID.Text.Trim();
        subjectId = cbSubject.SelectedValue?.ToString();
        score = 0;

        if (string.IsNullOrWhiteSpace(studentCode))
        {
            MessageBox.Show("Please enter the Student ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(subjectId))
        {
            MessageBox.Show("Please select a subject.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (!float.TryParse(txtScore.Text, out score) || score < 0 || score > 100)
        {
            MessageBox.Show("Please enter a valid score between 0 and 100.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }

    private void btnBack_Click(object sender, EventArgs e)
    {
        Dashboard MainForm = new Dashboard();
        MainForm.Show();
        this.Hide(); // Hide the login form
    }

    private void btnLogOut_Click(object sender, EventArgs e)
    {
        Login LoginForm = new Login();
        LoginForm.Show();
        this.Hide(); // Hide the login form
    }
}

public class DatabaseHelper
{
    private readonly string _connectionString;

    public DatabaseHelper(string connectionString)
    {
        _connectionString = connectionString;
    }

    public SqlConnection GetConnection()
    {
        return new SqlConnection(_connectionString);
    }
}

public class StudentManager
{
    private readonly DatabaseHelper _dbHelper;

    public StudentManager(DatabaseHelper dbHelper)
    {
        _dbHelper = dbHelper;
    }

    public void FetchStudentDetails(string studentId, ComboBox cbStuName, PictureBox picStudent)
    {
        using (var connection = _dbHelper.GetConnection())
        {
            connection.Open();
            string query = "SELECT first_name, last_name, photo FROM Students WHERE student_id = @student_id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@student_id", studentId);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                cbStuName.Text = $"{reader["first_name"]} {reader["last_name"]}";

                if (reader["photo"] != DBNull.Value)
                {
                    byte[] photoBytes = (byte[])reader["photo"];
                    using (MemoryStream stream = new MemoryStream(photoBytes))
                    {
                        picStudent.Image = Image.FromStream(stream);
                    }
                }
                else
                {
                    picStudent.Image = null;
                }
            }
            else
            {
                MessageBox.Show("Student ID not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cbStuName.Text = "";
                picStudent.Image = null;
            }
        }
    }

    public void PopulateStudentNames(ComboBox cbStuName)
    {
        using (var connection = _dbHelper.GetConnection())
        {
            connection.Open();
            string query = "SELECT student_id, first_name, last_name FROM Students";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            dt.Columns.Add("FullName", typeof(string), "first_name + ' ' + last_name");

            cbStuName.DataSource = dt;
            cbStuName.DisplayMember = "FullName";
            cbStuName.ValueMember = "student_id";
        }
    }

    public void LoadStudentScores(DataGridView dgvStu)
    {
        using (var connection = _dbHelper.GetConnection())
        {
            connection.Open();
            string query = @"
                    SELECT s.student_id AS StudentID,
                           CONCAT(s.first_name, ' ', s.last_name) AS StudentName,
                           MAX(CASE WHEN sub.subject_name = 'Mathematics' THEN sc.score END) AS MathScore,
                           MAX(CASE WHEN sub.subject_name = 'Science' THEN sc.score END) AS ScienceScore,
                           MAX(CASE WHEN sub.subject_name = 'History' THEN sc.score END) AS HistoryScore
                    FROM Students s
                    LEFT JOIN Scores sc ON s.id = sc.student_id
                    LEFT JOIN Subjects sub ON sc.subject_id = sub.subject_id
                    GROUP BY s.student_id, s.first_name, s.last_name";

            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            dgvStu.DataSource = dt;
            dgvStu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
    }

    public void HandleStudentSelection(DataGridViewRow selectedRow, TextBox txtStuID, ComboBox cbStuName, ComboBox cbSubject, TextBox txtScore)
    {
        txtStuID.Text = selectedRow.Cells["StudentID"].Value.ToString();
        cbStuName.Text = selectedRow.Cells["StudentName"].Value.ToString();
    }
}

public class SubjectManager
{
    private readonly DatabaseHelper _dbHelper;

    public SubjectManager(DatabaseHelper dbHelper)
    {
        _dbHelper = dbHelper;
    }

    public void LoadSubjects(ComboBox cbSubject)
    {
        using (var connection = _dbHelper.GetConnection())
        {
            connection.Open();
            string query = "SELECT subject_id, subject_name FROM Subjects";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            cbSubject.DataSource = dt;
            cbSubject.DisplayMember = "subject_name";  // The column to display
            cbSubject.ValueMember = "subject_id";      // The column to use as the value
        }
    }
}

public class ScoreManager
{
    private readonly DatabaseHelper _dbHelper;

    public ScoreManager(DatabaseHelper dbHelper)
    {
        _dbHelper = dbHelper;
    }
    public void FetchStudentScore(string studentId, string subjectId, TextBox txtScore)
    {
        try
        {
            using (var connection = _dbHelper.GetConnection())
            {
                connection.Open();

                // SQL query to fetch the student's score for the selected subject
                string query = @"
                SELECT sc.score
                FROM Scores sc
                INNER JOIN Students s ON s.id = sc.student_id
                INNER JOIN Subjects sub ON sub.subject_id = sc.subject_id
                WHERE s.student_id = @student_id AND sub.subject_id = @subject_id";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@student_id", studentId);
                command.Parameters.AddWithValue("@subject_id", subjectId);

                object result = command.ExecuteScalar();

                // Update the txtScore with the fetched score, or clear it if no score exists
                txtScore.Text = result?.ToString() ?? string.Empty;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error fetching score: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    public void InsertStudentScore(string studentCode, string subjectId, float score, DataGridView dgvStu)
    {
        using (var connection = _dbHelper.GetConnection())
        {
            connection.Open();
            string fetchStudentIdQuery = "SELECT id FROM Students WHERE student_id = @student_code";
            SqlCommand fetchCommand = new SqlCommand(fetchStudentIdQuery, connection);
            fetchCommand.Parameters.AddWithValue("@student_code", studentCode);

            object studentIdObj = fetchCommand.ExecuteScalar();

            if (studentIdObj == null)
            {
                MessageBox.Show("Student ID not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int studentId = Convert.ToInt32(studentIdObj);

            string insertQuery = "INSERT INTO Scores (student_id, subject_id, score) VALUES (@student_id, @subject_id, @score)";
            SqlCommand insertCommand = new SqlCommand(insertQuery, connection);
            insertCommand.Parameters.AddWithValue("@student_id", studentId);
            insertCommand.Parameters.AddWithValue("@subject_id", subjectId);
            insertCommand.Parameters.AddWithValue("@score", score);

            int rowsAffected = insertCommand.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Score inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Reload the DataGridView
                var studentManager = new StudentManager(_dbHelper);
                studentManager.LoadStudentScores(dgvStu);
            }
            else
            {
                MessageBox.Show("Failed to insert the score.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }



    public void UpdateStudentScore(string studentId, string subjectId, float score, DataGridView dgvStu)
    {
        using (var connection = _dbHelper.GetConnection())
        {
            connection.Open();
            string updateQuery = @"
                UPDATE Scores
                SET score = @score
                WHERE student_id = (SELECT id FROM Students WHERE student_id = @student_id)
                AND subject_id = @subject_id";

            SqlCommand updateCommand = new SqlCommand(updateQuery, connection);
            updateCommand.Parameters.AddWithValue("@student_id", studentId);
            updateCommand.Parameters.AddWithValue("@subject_id", subjectId);
            updateCommand.Parameters.AddWithValue("@score", score);

            int rowsAffected = updateCommand.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Score updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Reload the DataGridView
                var studentManager = new StudentManager(_dbHelper);
                studentManager.LoadStudentScores(dgvStu);
            }
            else
            {
                MessageBox.Show("Failed to update the score.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

}
