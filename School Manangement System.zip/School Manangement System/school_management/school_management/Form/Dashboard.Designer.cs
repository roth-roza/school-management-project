﻿namespace school_management
{
    partial class Dashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            panelHeader = new Panel();
            labelTitle = new Label();
            btnLogout = new Button();
            panelSidebar = new Panel();
            btnStudent = new Button();
            btnTeacher = new Button();
            btnScore = new Button();
            btnClassroom = new Button();
            panelMain = new Panel();
            pictureBoxMain = new PictureBox();
            panelHeader.SuspendLayout();
            panelSidebar.SuspendLayout();
            panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMain).BeginInit();
            SuspendLayout();
            // 
            // panelHeader
            // 
            panelHeader.BackColor = Color.FromArgb(34, 40, 49);
            panelHeader.Controls.Add(labelTitle);
            panelHeader.Controls.Add(btnLogout);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Location = new Point(0, 0);
            panelHeader.Margin = new Padding(3, 4, 3, 4);
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(919, 80);
            panelHeader.TabIndex = 0;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            labelTitle.ForeColor = Color.White;
            labelTitle.Location = new Point(23, 20);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(380, 37);
            labelTitle.TabIndex = 0;
            labelTitle.Text = "School Management System";
            // 
            // btnLogout
            // 
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.BackColor = Color.FromArgb(238, 68, 68);
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(805, 20);
            btnLogout.Margin = new Padding(3, 4, 3, 4);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(91, 40);
            btnLogout.TabIndex = 1;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += BtnLogout_Click;
            // 
            // panelSidebar
            // 
            panelSidebar.BackColor = Color.FromArgb(57, 62, 70);
            panelSidebar.Controls.Add(btnStudent);
            panelSidebar.Controls.Add(btnTeacher);
            panelSidebar.Controls.Add(btnScore);
            panelSidebar.Controls.Add(btnClassroom);
            panelSidebar.Dock = DockStyle.Left;
            panelSidebar.Location = new Point(0, 80);
            panelSidebar.Margin = new Padding(3, 4, 3, 4);
            panelSidebar.Name = "panelSidebar";
            panelSidebar.Size = new Size(229, 539);
            panelSidebar.TabIndex = 1;
            // 
            // btnStudent
            // 
            btnStudent.Dock = DockStyle.Top;
            btnStudent.FlatAppearance.BorderSize = 0;
            btnStudent.FlatStyle = FlatStyle.Flat;
            btnStudent.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnStudent.ForeColor = Color.White;
            btnStudent.Location = new Point(0, 240);
            btnStudent.Margin = new Padding(3, 4, 3, 4);
            btnStudent.Name = "btnStudent";
            btnStudent.Size = new Size(229, 80);
            btnStudent.TabIndex = 0;
            btnStudent.Text = "Students";
            btnStudent.UseVisualStyleBackColor = true;
            btnStudent.Click += btnStudent_Click;
            // 
            // btnTeacher
            // 
            btnTeacher.Dock = DockStyle.Top;
            btnTeacher.FlatAppearance.BorderSize = 0;
            btnTeacher.FlatStyle = FlatStyle.Flat;
            btnTeacher.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnTeacher.ForeColor = Color.White;
            btnTeacher.Location = new Point(0, 160);
            btnTeacher.Margin = new Padding(3, 4, 3, 4);
            btnTeacher.Name = "btnTeacher";
            btnTeacher.Size = new Size(229, 80);
            btnTeacher.TabIndex = 1;
            btnTeacher.Text = "Teachers";
            btnTeacher.UseVisualStyleBackColor = true;
            btnTeacher.Click += btnTeacher_Click;
            // 
            // btnScore
            // 
            btnScore.Dock = DockStyle.Top;
            btnScore.FlatAppearance.BorderSize = 0;
            btnScore.FlatStyle = FlatStyle.Flat;
            btnScore.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnScore.ForeColor = Color.White;
            btnScore.Location = new Point(0, 80);
            btnScore.Margin = new Padding(3, 4, 3, 4);
            btnScore.Name = "btnScore";
            btnScore.Size = new Size(229, 80);
            btnScore.TabIndex = 2;
            btnScore.Text = "Scores";
            btnScore.UseVisualStyleBackColor = true;
            btnScore.Click += btnScore_Click_1;
            // 
            // btnClassroom
            // 
            btnClassroom.Dock = DockStyle.Top;
            btnClassroom.FlatAppearance.BorderSize = 0;
            btnClassroom.FlatStyle = FlatStyle.Flat;
            btnClassroom.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnClassroom.ForeColor = Color.White;
            btnClassroom.Location = new Point(0, 0);
            btnClassroom.Margin = new Padding(3, 4, 3, 4);
            btnClassroom.Name = "btnClassroom";
            btnClassroom.Size = new Size(229, 80);
            btnClassroom.TabIndex = 3;
            btnClassroom.Text = "Classrooms";
            btnClassroom.UseVisualStyleBackColor = true;
            btnClassroom.Click += btnClassroom_Click;
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.FromArgb(57, 62, 70);
            panelMain.Controls.Add(pictureBoxMain);
            panelMain.Dock = DockStyle.Fill;
            panelMain.Location = new Point(229, 80);
            panelMain.Margin = new Padding(3, 4, 3, 4);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(690, 539);
            panelMain.TabIndex = 2;
            // 
            // pictureBoxMain
            // 
            pictureBoxMain.Anchor = AnchorStyles.None;
            pictureBoxMain.Image = (Image)resources.GetObject("pictureBoxMain.Image");
            pictureBoxMain.Location = new Point(-1, 0);
            pictureBoxMain.Margin = new Padding(3, 4, 3, 4);
            pictureBoxMain.Name = "pictureBoxMain";
            pictureBoxMain.Size = new Size(691, 539);
            pictureBoxMain.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxMain.TabIndex = 0;
            pictureBoxMain.TabStop = false;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(919, 619);
            Controls.Add(panelMain);
            Controls.Add(panelSidebar);
            Controls.Add(panelHeader);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "Dashboard";
            Text = "Dashboard";
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            panelSidebar.ResumeLayout(false);
            panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBoxMain).EndInit();
            ResumeLayout(false);
        }

        private Panel panelHeader;
        private Label labelTitle;
        private Button btnLogout;
        private Panel panelSidebar;
        private Button btnStudent;
        private Button btnTeacher;
        private Button btnScore;
        private Button btnClassroom;
        private Panel panelMain;
        private PictureBox pictureBoxMain;

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            Login Login = new Login();
            Login.Show();
            this.Hide(); // Hide the login form
        }
    }
}
